const express = require('express');
const cors = require('cors');
const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb');

const app = express();
const PORT = 5000;

// AWS SDK v3 DynamoDB client configuration
const dbClient = new DynamoDBClient({
  region: 'us-east-1', // 🔁 change to your AWS region
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,     // store these in env vars
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  }
});

app.use(cors());

// Simple greeting endpoint
app.get('/api/greeting', (req, res) => {
  res.json({ greeting: 'Hello from your Node backend!' });
});

// Fetch items from DynamoDB
app.get('/api/items', async (req, res) => {
  try {
    const data = await dbClient.send(new ScanCommand({
      TableName: 'my-app' // 🔁 replace with your table name
    }));

    res.json({ items: data.Items });
  } catch (err) {
    console.error('Error fetching data from DynamoDB:', err);
    res.status(500).json({ error: 'Failed to fetch data' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

